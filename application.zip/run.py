"""
    This python file will simply run the server
"""
from server_routes import APP

APP.run(debug=True)
