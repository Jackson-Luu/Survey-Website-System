''' testing enrolling of a student '''

'''enrolling a student that doesn't exist'''

'''enrolling a student succesfully'''